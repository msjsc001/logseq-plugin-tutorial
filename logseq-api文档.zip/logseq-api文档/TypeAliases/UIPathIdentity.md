  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [UIPathIdentity](UIPathIdentity.html)



# Type alias UIPathIdentity

UIPathIdentity: {   
path: string;   
}

#### Type declaration

  * ##### path: string

DOM selector




  * Defined in [src/LSPlugin.ts:50](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L50)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
