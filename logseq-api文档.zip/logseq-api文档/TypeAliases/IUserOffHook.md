  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [IUserOffHook](IUserOffHook.html)



# Type alias IUserOffHook

IUserOffHook: (() => void)

#### Type declaration

  *     * (): void
    * #### Returns void




  * Defined in [src/LSPlugin.ts:98](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L98)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
