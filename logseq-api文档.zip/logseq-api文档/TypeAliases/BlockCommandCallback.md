  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [BlockCommandCallback](BlockCommandCallback.html)



# Type alias BlockCommandCallback

BlockCommandCallback: ((e: [IHookEvent](IHookEvent.html) & {   
uuid: [BlockUUID](BlockUUID.html);   
}) => Promise<void>)

#### Type declaration

  *     * (e: [IHookEvent](IHookEvent.html) & {   
uuid: [BlockUUID](BlockUUID.html);   
}): Promise<void>
    * #### Parameters

      * ##### e: [IHookEvent](IHookEvent.html) & {   
uuid: [BlockUUID](BlockUUID.html);   
}

#### Returns Promise<void>




  * Defined in [src/LSPlugin.ts:222](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L222)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
