  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [UISlotIdentity](UISlotIdentity.html)



# Type alias UISlotIdentity

UISlotIdentity: {   
slot: string;   
}

#### Type declaration

  * ##### slot: string

Slot key




  * Defined in [src/LSPlugin.ts:57](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L57)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
