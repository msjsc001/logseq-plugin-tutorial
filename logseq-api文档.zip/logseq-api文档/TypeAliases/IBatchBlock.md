  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [IBatchBlock](IBatchBlock.html)



# Type alias IBatchBlock

IBatchBlock: {   
children?: [IBatchBlock](IBatchBlock.html)[];   
content: string;   
properties?: Record<string, any>;   
}

#### Type declaration

  * ##### `Optional` children?: [IBatchBlock](IBatchBlock.html)[]

  * ##### content: string

  * ##### `Optional` properties?: Record<string, any>




  * Defined in [src/LSPlugin.ts:115](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L115)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
