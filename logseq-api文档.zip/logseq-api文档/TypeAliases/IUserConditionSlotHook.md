  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [IUserConditionSlotHook](IUserConditionSlotHook.html)



# Type alias IUserConditionSlotHook<C, E>

IUserConditionSlotHook<C, E>: ((condition: C, callback: ((e: [IHookEvent](IHookEvent.html) & [UISlotIdentity](UISlotIdentity.html) & E) => void)) => void)

#### Type Parameters

  * #### C = any

  * #### E = any




#### Type declaration

  *     * (condition: C, callback: ((e: [IHookEvent](IHookEvent.html) & [UISlotIdentity](UISlotIdentity.html) & E) => void)): void
    * #### Parameters

      * ##### condition: C

      * ##### callback: ((e: [IHookEvent](IHookEvent.html) & [UISlotIdentity](UISlotIdentity.html) & E) => void)

        *           * (e: [IHookEvent](IHookEvent.html) & [UISlotIdentity](UISlotIdentity.html) & E): void
          * #### Parameters

            * ##### e: [IHookEvent](IHookEvent.html) & [UISlotIdentity](UISlotIdentity.html) & E

#### Returns void

#### Returns void




  * Defined in [src/LSPlugin.ts:105](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L105)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
