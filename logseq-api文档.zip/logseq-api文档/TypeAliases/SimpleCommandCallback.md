  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [SimpleCommandCallback](SimpleCommandCallback.html)



# Type alias SimpleCommandCallback<E>

SimpleCommandCallback<E>: ((e: [IHookEvent](IHookEvent.html) & E) => void)

#### Type Parameters

  * #### E = any




#### Type declaration

  *     * (e: [IHookEvent](IHookEvent.html) & E): void
    * #### Parameters

      * ##### e: [IHookEvent](IHookEvent.html) & E

#### Returns void




  * Defined in [src/LSPlugin.ts:221](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L221)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
