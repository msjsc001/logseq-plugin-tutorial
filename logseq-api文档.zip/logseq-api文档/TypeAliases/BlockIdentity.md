  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [BlockIdentity](BlockIdentity.html)



# Type alias BlockIdentity

BlockIdentity: [BlockUUID](BlockUUID.html) | Pick<[BlockEntity](../interfaces/BlockEntity.html), "uuid">

  * Defined in [src/LSPlugin.ts:212](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L212)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
