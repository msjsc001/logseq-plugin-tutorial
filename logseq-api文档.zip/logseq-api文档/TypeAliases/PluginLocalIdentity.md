  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [PluginLocalIdentity](PluginLocalIdentity.html)



# Type alias PluginLocalIdentity

PluginLocalIdentity: string

  * Defined in [src/LSPlugin.ts:11](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L11)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
