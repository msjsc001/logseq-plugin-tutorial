  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [SearchPageItem](SearchPageItem.html)



# Type alias SearchPageItem

SearchPageItem: string

  * Defined in [src/LSPlugin.ts:298](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L298)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
