  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [UIPathOptions](UIPathOptions.html)



# Type alias UIPathOptions

UIPathOptions: [UIBaseOptions](UIBaseOptions.html) & [UIPathIdentity](UIPathIdentity.html)

  * Defined in [src/LSPlugin.ts:66](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L66)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
