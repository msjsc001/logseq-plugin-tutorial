  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [BlockUUIDTuple](BlockUUIDTuple.html)



# Type alias BlockUUIDTuple

BlockUUIDTuple: ["uuid", [BlockUUID](BlockUUID.html)]

  * Defined in [src/LSPlugin.ts:112](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L112)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
