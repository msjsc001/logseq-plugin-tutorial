  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [EntityID](EntityID.html)



# Type alias EntityID

EntityID: number

  * Defined in [src/LSPlugin.ts:110](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L110)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
