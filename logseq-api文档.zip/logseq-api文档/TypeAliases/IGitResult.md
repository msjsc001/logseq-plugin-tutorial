  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [IGitResult](IGitResult.html)



# Type alias IGitResult

IGitResult: {   
exitCode: number;   
stderr: string;   
stdout: string;   
}

#### Type declaration

  * ##### exitCode: number

  * ##### stderr: string

  * ##### stdout: string




  * Defined in [src/LSPlugin.ts:122](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L122)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
