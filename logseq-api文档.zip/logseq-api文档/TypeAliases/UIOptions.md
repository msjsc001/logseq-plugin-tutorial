  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [UIOptions](UIOptions.html)



# Type alias UIOptions

UIOptions: [UIBaseOptions](UIBaseOptions.html) | [UIPathOptions](UIPathOptions.html) | [UISlotOptions](UISlotOptions.html)

  * Defined in [src/LSPlugin.ts:68](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L68)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
