  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [SearchBlockItem](SearchBlockItem.html)



# Type alias SearchBlockItem

SearchBlockItem: {   
content: string;   
id: [EntityID](EntityID.html);   
page: [EntityID](EntityID.html);   
uuid: [BlockIdentity](BlockIdentity.html);   
}

#### Type declaration

  * ##### content: string

  * ##### id: [EntityID](EntityID.html)

  * ##### page: [EntityID](EntityID.html)

  * ##### uuid: [BlockIdentity](BlockIdentity.html)




  * Defined in [src/LSPlugin.ts:297](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L297)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
