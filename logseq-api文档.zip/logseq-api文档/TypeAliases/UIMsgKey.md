  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [UIMsgKey](UIMsgKey.html)



# Type alias UIMsgKey

UIMsgKey: [UIMsgOptions](UIMsgOptions.html)["key"]

  * Defined in [src/LSPlugin.ts:856](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L856)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
