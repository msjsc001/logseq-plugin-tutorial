  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [UIMsgOptions](UIMsgOptions.html)



# Type alias UIMsgOptions

UIMsgOptions: {   
key: string;   
timeout: number;   
}

UI related APIs

#### Type declaration

  * ##### key: string

  * ##### timeout: number




  * Defined in [src/LSPlugin.ts:851](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L851)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
