  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [IUserSlotHook](IUserSlotHook.html)



# Type alias IUserSlotHook<E>

IUserSlotHook<E>: ((callback: ((e: [IHookEvent](IHookEvent.html) & [UISlotIdentity](UISlotIdentity.html) & E) => void)) => void)

#### Type Parameters

  * #### E = any




#### Type declaration

  *     * (callback: ((e: [IHookEvent](IHookEvent.html) & [UISlotIdentity](UISlotIdentity.html) & E) => void)): void
    * #### Parameters

      * ##### callback: ((e: [IHookEvent](IHookEvent.html) & [UISlotIdentity](UISlotIdentity.html) & E) => void)

        *           * (e: [IHookEvent](IHookEvent.html) & [UISlotIdentity](UISlotIdentity.html) & E): void
          * #### Parameters

            * ##### e: [IHookEvent](IHookEvent.html) & [UISlotIdentity](UISlotIdentity.html) & E

#### Returns void

#### Returns void




  * Defined in [src/LSPlugin.ts:102](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L102)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
