  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [SimpleCommandKeybinding](SimpleCommandKeybinding.html)



# Type alias SimpleCommandKeybinding

SimpleCommandKeybinding: {   
binding: string;   
mac?: string;   
mode?: "global" | "non-editing" | "editing";   
}

#### Type declaration

  * ##### binding: string

  * ##### `Optional` mac?: string

  * ##### `Optional` mode?: "global" | "non-editing" | "editing"




  * Defined in [src/LSPlugin.ts:233](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L233)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
