  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [UIContainerAttrs](UIContainerAttrs.html)



# Type alias UIContainerAttrs

UIContainerAttrs: {   
draggable: boolean;   
resizable: boolean;   
[key: string]: any;   
}

#### Type declaration

  * ##### [key: string]: any

  * ##### draggable: boolean

  * ##### resizable: boolean




  * Defined in [src/LSPlugin.ts:33](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L33)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
