  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [setupPluginUserInstance](setupPluginUserInstance.html)



# Function setupPluginUserInstance

  * setupPluginUserInstance(pluginBaseInfo: [LSPluginBaseInfo](../interfaces/LSPluginBaseInfo.html), pluginCaller: LSPluginCaller): [LSPluginUser](../classes/LSPluginUser.html)
  * `Internal`

#### Parameters

    * ##### pluginBaseInfo: [LSPluginBaseInfo](../interfaces/LSPluginBaseInfo.html)

    * ##### pluginCaller: LSPluginCaller

#### Returns [LSPluginUser](../classes/LSPluginUser.html)

    * Defined in [src/LSPlugin.user.ts:846](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.user.ts#L846)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
