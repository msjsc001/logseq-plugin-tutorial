  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [AppInfo](AppInfo.html)



# Interface AppInfo

#### Hierarchy

  * AppInfo



#### Indexable

[key: string]: any

  * Defined in [src/LSPlugin.ts:128](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L128)



#####  Index

### Properties

[version](AppInfo.html#version)

## Properties

### version

version: string

  * Defined in [src/LSPlugin.ts:129](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L129)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
