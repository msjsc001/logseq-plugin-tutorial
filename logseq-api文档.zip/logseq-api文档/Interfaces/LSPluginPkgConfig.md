  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [LSPluginPkgConfig](LSPluginPkgConfig.html)



# Interface LSPluginPkgConfig

#### Hierarchy

  * LSPluginPkgConfig



#### Indexable

[key: string]: any

  * Defined in [src/LSPlugin.ts:70](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L70)



#####  Index

### Properties

[entry](LSPluginPkgConfig.html#entry) [icon](LSPluginPkgConfig.html#icon) [id](LSPluginPkgConfig.html#id) [main](LSPluginPkgConfig.html#main) [mode](LSPluginPkgConfig.html#mode) [themes](LSPluginPkgConfig.html#themes) [title](LSPluginPkgConfig.html#title)

## Properties

### entry

entry: string

  * Defined in [src/LSPlugin.ts:73](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L73)



### icon

icon: string

  * Defined in [src/LSPlugin.ts:77](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L77)



### id

id: string

  * Defined in [src/LSPlugin.ts:71](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L71)



### main

main: string

  * Defined in [src/LSPlugin.ts:72](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L72)



### mode

mode: "iframe" | "shadow"

  * Defined in [src/LSPlugin.ts:75](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L75)



### themes

themes: [Theme](Theme.html)[]

  * Defined in [src/LSPlugin.ts:76](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L76)



### title

title: string

  * Defined in [src/LSPlugin.ts:74](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L74)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
