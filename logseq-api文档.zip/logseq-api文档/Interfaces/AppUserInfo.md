  * Preparing search index...
  * The search index is not available

[@logseq/libs]()

  * [@logseq/libs](../modules.html)
  * [AppUserInfo](AppUserInfo.html)



# Interface AppUserInfo

#### Hierarchy

  * AppUserInfo



#### Indexable

[key: string]: any

  * Defined in [src/LSPlugin.ts:124](https://github.com/logseq/logseq/blob/ac1b53544/libs/src/LSPlugin.ts#L124)



###  Settings

#### Member Visibility

  * Protected
  * Private
  * Inherited
  * External



#### Theme

OSLightDark

Generated using [TypeDoc](https://typedoc.org/)
